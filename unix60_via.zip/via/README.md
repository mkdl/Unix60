1. Flash µC with Unix60_Via.hex
2. Open Via and go to the "Design" Tab
3. Click "load" and open the unix60.json
4. You can now use Via to change your Unix60 keymap
